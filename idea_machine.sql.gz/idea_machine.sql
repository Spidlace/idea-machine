-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Client :  127.0.0.1
-- Généré le :  Mar 22 Août 2017 à 22:54
-- Version du serveur :  5.7.14
-- Version de PHP :  5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `idea_machine`
--

-- --------------------------------------------------------

--
-- Structure de la table `idea`
--

CREATE TABLE `idea` (
  `id` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8_unicode_ci NOT NULL,
  `image_id` int(11) DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Contenu de la table `idea`
--

INSERT INTO `idea` (`id`, `date`, `title`, `content`, `image_id`, `slug`, `user_id`) VALUES
(27, '2017-08-22 22:30:59', 'Ma première idée', 'Ceci est ma première idée.', 27, 'ma-premiere-idee', 5),
(28, '2017-08-22 22:33:49', 'Ma deuxième idée avec un titre long', 'Interdum et malesuada fames ac ante ipsum primis in faucibus. Aliquam eleifend euismod quam eu consectetur. Vivamus pretium libero ut faucibus egestas. Duis luctus metus ut lectus aliquet venenatis sed quis ex. \r\n\r\nSed molestie et tellus ut malesuada. Etiam vehicula dui dolor, quis dignissim turpis tempus non. Nam non pulvinar tellus. Duis tristique sem quam, ac venenatis libero finibus cursus. Mauris eget hendrerit mauris, id porttitor ipsum. Vestibulum vehicula consectetur turpis vel porttitor. Suspendisse vitae consectetur mauris. Sed accumsan sollicitudin rutrum. Vestibulum in augue in metus rhoncus semper. Ut feugiat, metus cursus volutpat accumsan, tortor urna tempor massa, non scelerisque metus ipsum eu sem.', 28, 'ma-deuxieme-idee-avec-un-titre-long', 5),
(29, '2017-08-22 22:34:54', 'Ma troisième idée, consectetur adipiscing elit', 'Interdum et malesuada fames ac ante ipsum primis in faucibus. Aliquam eleifend euismod quam eu consectetur. Vivamus pretium libero ut faucibus egestas. Duis luctus metus ut lectus aliquet venenatis sed quis ex. Sed molestie et tellus ut malesuada. Etiam vehicula dui dolor, quis dignissim turpis tempus non. Nam non pulvinar tellus. Duis tristique sem quam, ac venenatis libero finibus cursus. Mauris eget hendrerit mauris, id porttitor ipsum. Vestibulum vehicula consectetur turpis vel porttitor. Suspendisse vitae consectetur mauris. Sed accumsan sollicitudin rutrum. Vestibulum in augue in metus rhoncus semper. Ut feugiat, metus cursus volutpat accumsan, tortor urna tempor massa, non scelerisque metus ipsum eu sem.', 29, 'ma-troisieme-idee-consectetur-adipiscing-elit', 5),
(30, '2017-08-22 22:36:06', 'Ma super quatrième idée', 'Cras suscipit faucibus tristique. Aenean fermentum orci sit amet nibh eleifend, sed lacinia enim mollis. Sed auctor tellus sed ligula laoreet, in commodo purus euismod.', 30, 'ma-super-quatrieme-idee', 5),
(31, '2017-08-22 22:37:44', 'Ma cinquième idée', 'Ut vitae hendrerit turpis. Nunc at felis non neque lobortis eleifend sagittis sed quam. Aenean diam erat, laoreet vel mollis pulvinar, imperdiet a lacus. Mauris efficitur fringilla tempor. Fusce commodo libero felis, sit amet tempus magna tempus et. Vestibulum consequat in erat nec suscipit. Integer at felis a quam egestas malesuada. Vestibulum rhoncus placerat imperdiet.', 31, 'ma-cinquieme-idee', 5),
(32, '2017-08-22 22:38:31', 'Ma sixième idée (à modifier)', 'Curabitur faucibus augue vitae consectetur maximus. Nunc pulvinar ut metus non sagittis. Nunc non diam fringilla ante tristique convallis. Pellentesque tempor ac felis sit amet fermentum. Nullam facilisis tortor eget sem ultrices auctor. Aliquam eget dictum augue. Donec finibus felis augue, id blandit nisl tempor at. Aliquam pharetra nisl a lectus mollis, euismod facilisis mi tempus. Aliquam accumsan est non elit convallis bibendum.', 32, 'ma-sixieme-idee-a-modifier', 5),
(33, '2017-08-22 22:39:59', 'Apprendre à faire un site sous Symfony', 'Pour un utilisateur anonyme de :\r\n- consulter des idées \r\n- se connecter ( via email / mdp pre définis côté serveur )\r\n\r\nPour un utilisateur connecté de :\r\n- consulter des idées\r\n- se déconnecter\r\n- ajouter une idée \r\n- modifier les idées dont il est l’auteur\r\n- supprimer les idées dont il est l’auteur\r\n- voter (upvote / downvote) pour des idées (une fois par idée) directement depuis la home', 33, 'apprendre-a-faire-un-site-sous-symfony', 5);

-- --------------------------------------------------------

--
-- Structure de la table `idea_image`
--

CREATE TABLE `idea_image` (
  `id` int(11) NOT NULL,
  `url` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `alt` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Contenu de la table `idea_image`
--

INSERT INTO `idea_image` (`id`, `url`, `alt`) VALUES
(27, 'jpeg', 'valeur-idee.jpg'),
(28, 'jpeg', '42259c58eab19eff3c73b7276693969b4057f0a3-shutterstock_553007902.jpg'),
(29, 'jpeg', 'hn58TGji1NZ2TH_G7G3DuABnHn9TYaE62MzCM3bbn4E.jpg'),
(30, 'jpeg', 'shutterstock-creative-trends-2017.jpg'),
(31, 'jpeg', 'code-1839406_960_720.jpg'),
(32, 'jpeg', '3.jpg'),
(33, 'jpeg', 'logo-symfony.jpg');

-- --------------------------------------------------------

--
-- Structure de la table `idea_user`
--

CREATE TABLE `idea_user` (
  `id` int(11) NOT NULL,
  `username` varchar(180) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `salt` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `roles` longtext COLLATE utf8_unicode_ci NOT NULL COMMENT '(DC2Type:array)',
  `username_canonical` varchar(180) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(180) COLLATE utf8_unicode_ci NOT NULL,
  `email_canonical` varchar(180) COLLATE utf8_unicode_ci NOT NULL,
  `enabled` tinyint(1) NOT NULL,
  `last_login` datetime DEFAULT NULL,
  `confirmation_token` varchar(180) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password_requested_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Contenu de la table `idea_user`
--

INSERT INTO `idea_user` (`id`, `username`, `password`, `salt`, `roles`, `username_canonical`, `email`, `email_canonical`, `enabled`, `last_login`, `confirmation_token`, `password_requested_at`) VALUES
(5, 'anthony', 'mfYKqPO8Krx0mHzn4jL71EHJARvb6Kk37FJ2ANwjluxDMG0BNxkho0lKBJDnkqWlFHtq7Znu3ZhUjtfIlHGfJQ==', 'OoZVWjuCLr0N8WV8CLgD7d/hHcsHtZ9PvJUXOef6qg8', 'a:1:{i:0;s:11:"ROLE_AUTEUR";}', 'anthony', 'anthony@idea-machine.dev', 'anthony@idea-machine.dev', 1, '2017-08-22 22:06:17', NULL, NULL),
(6, 'damien', 'wYVJyjMML7w71rZX8ZfRySSwsyAzpED8sqywB76/HdablwQysTqNHmbpkPa9IcV9P4DmgmXZks6NjOUjlyb0IQ==', 'QrqDUiGcurYqpr.HTjIaFmGxhh1Y3XVJWYNR0TKim2A', 'a:1:{i:0;s:11:"ROLE_AUTEUR";}', 'damien', 'damien@idea-machine.dev', 'damien@idea-machine.dev', 1, '2017-08-22 19:32:33', NULL, NULL),
(7, 'admin', 'FOmT5AZnGrpIiF3Yo5TAXo2aM0vGhmUwuOBxKar5B9f7Skba3eeqD2kNfr4rbBFxKCLTYngiEdM7tR/7Y/t3YQ==', 'COLZE3GyMwpw5tA3IHXLMxVB..JtYWb7mVqZn21DJbc', 'a:1:{i:0;s:10:"ROLE_ADMIN";}', 'admin', 'admin@idea-machine.dev', 'admin@idea-machine.dev', 1, '2017-08-22 17:26:39', NULL, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `idea_vote`
--

CREATE TABLE `idea_vote` (
  `id` int(11) NOT NULL,
  `idea_id` int(11) NOT NULL,
  `choix` longtext COLLATE utf8_unicode_ci NOT NULL,
  `date` datetime NOT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Contenu de la table `idea_vote`
--

INSERT INTO `idea_vote` (`id`, `idea_id`, `choix`, `date`, `user_id`) VALUES
(98, 33, '1', '2017-08-22 22:40:48', 5),
(99, 29, '-1', '2017-08-22 22:40:56', 5),
(100, 31, '1', '2017-08-22 22:41:02', 5),
(101, 27, '-1', '2017-08-22 22:41:07', 5);

--
-- Index pour les tables exportées
--

--
-- Index pour la table `idea`
--
ALTER TABLE `idea`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UNIQ_A8BCA45989D9B62` (`slug`),
  ADD UNIQUE KEY `UNIQ_A8BCA453DA5256D` (`image_id`),
  ADD KEY `IDX_A8BCA45A76ED395` (`user_id`);

--
-- Index pour la table `idea_image`
--
ALTER TABLE `idea_image`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `idea_user`
--
ALTER TABLE `idea_user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UNIQ_4EDA63E292FC23A8` (`username_canonical`),
  ADD UNIQUE KEY `UNIQ_4EDA63E2A0D96FBF` (`email_canonical`),
  ADD UNIQUE KEY `UNIQ_4EDA63E2C05FB297` (`confirmation_token`);

--
-- Index pour la table `idea_vote`
--
ALTER TABLE `idea_vote`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_995930CF5B6FEF7D` (`idea_id`),
  ADD KEY `IDX_995930CFA76ED395` (`user_id`);

--
-- AUTO_INCREMENT pour les tables exportées
--

--
-- AUTO_INCREMENT pour la table `idea`
--
ALTER TABLE `idea`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;
--
-- AUTO_INCREMENT pour la table `idea_image`
--
ALTER TABLE `idea_image`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;
--
-- AUTO_INCREMENT pour la table `idea_user`
--
ALTER TABLE `idea_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT pour la table `idea_vote`
--
ALTER TABLE `idea_vote`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=102;
--
-- Contraintes pour les tables exportées
--

--
-- Contraintes pour la table `idea`
--
ALTER TABLE `idea`
  ADD CONSTRAINT `FK_A8BCA453DA5256D` FOREIGN KEY (`image_id`) REFERENCES `idea_image` (`id`),
  ADD CONSTRAINT `FK_A8BCA45A76ED395` FOREIGN KEY (`user_id`) REFERENCES `idea_user` (`id`);

--
-- Contraintes pour la table `idea_vote`
--
ALTER TABLE `idea_vote`
  ADD CONSTRAINT `FK_995930CF5B6FEF7D` FOREIGN KEY (`idea_id`) REFERENCES `idea` (`id`),
  ADD CONSTRAINT `FK_995930CFA76ED395` FOREIGN KEY (`user_id`) REFERENCES `idea_user` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
